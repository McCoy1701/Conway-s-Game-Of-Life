FPS = 60
CELL_SIZE = 16
SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
TITLE = "Conway's Game Of Life"

COLORS = {
    0: 'black',
    1: 'gray33',
    2: 'gray',
    3: 'white'}
